<?php
require_once '../config/db.php';

header('Content-Type: application/json');

$saleId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($saleId < 1) {
    echo json_encode(['error' => 'Invalid sale ID']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM sales WHERE id = ?");
    $stmt->execute([$saleId]);
    $sale = $stmt->fetch();

    if (!$sale) {
        echo json_encode(['error' => 'Sale not found']);
        exit;
    }

    $itemsStmt = $pdo->prepare("SELECT * FROM sale_items WHERE sale_id = ?");
    $itemsStmt->execute([$saleId]);
    $items = $itemsStmt->fetchAll();

    echo json_encode([
        'sale' => $sale,
        'items' => $items
    ]);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error']);
}
?>
