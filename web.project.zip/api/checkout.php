<?php
require_once '../config/db.php';

header('Content-Type: application/json');

// Get JSON from request body
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || empty($input['items'])) {
    echo json_encode(['success' => false, 'message' => 'Empty cart']);
    exit;
}

$items = $input['items'];

try {
    $pdo->beginTransaction();

    // First check stock for all items, also fetch their current price + name from DB
    // (don't trust prices from client side)
    $verifiedItems = [];
    $total = 0;

    foreach ($items as $item) {
        $pid = intval($item['id']);
        $qty = intval($item['quantity']);

        if ($qty < 1) {
            throw new Exception("Invalid quantity");
        }

        $stmt = $pdo->prepare("SELECT id, name, price, stock FROM products WHERE id = ?");
        $stmt->execute([$pid]);
        $product = $stmt->fetch();

        if (!$product) {
            throw new Exception("Product not found");
        }

        if ($product['stock'] < $qty) {
            throw new Exception("Not enough stock for " . $product['name']);
        }

        $subtotal = $product['price'] * $qty;
        $total += $subtotal;

        $verifiedItems[] = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $qty,
            'subtotal' => $subtotal
        ];
    }

    // Insert sale record
    $stmt = $pdo->prepare("INSERT INTO sales (total) VALUES (?)");
    $stmt->execute([$total]);
    $saleId = $pdo->lastInsertId();

    // Insert sale items + reduce stock
    $itemStmt = $pdo->prepare("INSERT INTO sale_items (sale_id, product_id, product_name, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
    $stockStmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");

    foreach ($verifiedItems as $vi) {
        $itemStmt->execute([$saleId, $vi['id'], $vi['name'], $vi['quantity'], $vi['price'], $vi['subtotal']]);

        // Conditional update — prevents going negative
        $stockStmt->execute([$vi['quantity'], $vi['id'], $vi['quantity']]);
        if ($stockStmt->rowCount() === 0) {
            throw new Exception("Stock update failed for " . $vi['name']);
        }
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'sale_id' => $saleId,
        'total' => $total
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
