// ===== POS Frontend Script =====
// Handles product loading, search, cart logic, and checkout

// Simple Cart class - keeps things in memory and updates the DOM
class Cart {
    constructor() {
        this.items = [];
    }

    addItem(product) {
        // If item already exists, just add to quantity
        let existing = this.items.find(item => item.id === product.id);

        if (existing) {
            if (existing.quantity + 1 > product.stock) {
                alert("Not enough stock available!");
                return;
            }
            existing.quantity += 1;
        } else {
            if (product.stock < 1) {
                alert("Out of stock!");
                return;
            }
            this.items.push({
                id: product.id,
                name: product.name,
                price: parseFloat(product.price),
                quantity: 1,
                stock: product.stock
            });
        }
        this.render();
    }

    removeItem(id) {
        this.items = this.items.filter(item => item.id !== id);
        this.render();
    }

    updateQuantity(id, change) {
        let item = this.items.find(i => i.id === id);
        if (!item) return;

        let newQty = item.quantity + change;

        if (newQty < 1) {
            this.removeItem(id);
            return;
        }

        if (newQty > item.stock) {
            alert("Not enough stock!");
            return;
        }

        item.quantity = newQty;
        this.render();
    }

    calculateSubtotal() {
        return this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    }

    calculateTotal() {
        return this.calculateSubtotal();
    }

    clear() {
        this.items = [];
        this.render();
    }

    isEmpty() {
        return this.items.length === 0;
    }

    render() {
        const cartList = document.getElementById('cartList');
        cartList.innerHTML = '';

        if (this.isEmpty()) {
            cartList.innerHTML = '<li class="empty-cart">Cart is empty</li>';
        } else {
            this.items.forEach(item => {
                const li = document.createElement('li');
                li.className = 'cart-item';

                // Build DOM elements directly - more reliable than innerHTML with delegated events
                const info = document.createElement('div');
                info.className = 'item-info';
                info.innerHTML = `
                    <div class="item-name">${item.name}</div>
                    <div class="item-price">$${item.price.toFixed(2)} each</div>
                `;

                const qtyControls = document.createElement('div');
                qtyControls.className = 'qty-controls';

                const btnMinus = document.createElement('button');
                btnMinus.type = 'button';
                btnMinus.textContent = '-';
                btnMinus.addEventListener('click', () => this.updateQuantity(item.id, -1));

                const qtySpan = document.createElement('span');
                qtySpan.className = 'qty';
                qtySpan.textContent = item.quantity;

                const btnPlus = document.createElement('button');
                btnPlus.type = 'button';
                btnPlus.textContent = '+';
                btnPlus.addEventListener('click', () => this.updateQuantity(item.id, 1));

                qtyControls.appendChild(btnMinus);
                qtyControls.appendChild(qtySpan);
                qtyControls.appendChild(btnPlus);

                const subtotal = document.createElement('span');
                subtotal.className = 'subtotal';
                subtotal.textContent = '$' + (item.price * item.quantity).toFixed(2);

                const removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'remove-btn';
                removeBtn.textContent = 'X';
                removeBtn.title = 'Remove from cart';
                removeBtn.addEventListener('click', () => this.removeItem(item.id));

                li.appendChild(info);
                li.appendChild(qtyControls);
                li.appendChild(subtotal);
                li.appendChild(removeBtn);

                cartList.appendChild(li);
            });
        }

        document.getElementById('subtotal').textContent = '$' + this.calculateSubtotal().toFixed(2);
        document.getElementById('total').textContent = '$' + this.calculateTotal().toFixed(2);
    }
}

// ===== Initialize =====
const cart = new Cart();
let allProducts = [];

// Load products from server
function loadProducts() {
    fetch('api/get_products.php')
        .then(res => res.json())
        .then(data => {
            allProducts = data;
            renderProducts(allProducts);
        })
        .catch(err => {
            console.error("Failed to load products:", err);
            document.getElementById('productGrid').innerHTML =
                '<p class="loading">Error loading products.</p>';
        });
}

// Render products on screen
function renderProducts(products) {
    const grid = document.getElementById('productGrid');
    grid.innerHTML = '';

    if (products.length === 0) {
        grid.innerHTML = '<p class="loading">No products found.</p>';
        return;
    }

    products.forEach(p => {
        const card = document.createElement('div');
        card.className = 'product-card';
        if (p.stock < 1) card.classList.add('out-of-stock');

        const lowClass = p.stock <= 5 && p.stock > 0 ? 'low' : '';
        const stockText = p.stock < 1 ? 'Out of stock' : `Stock: ${p.stock}`;

        card.innerHTML = `
            <h3>${p.name}</h3>
            <div class="category">${p.category}</div>
            <div class="price">$${parseFloat(p.price).toFixed(2)}</div>
            <div class="stock ${lowClass}">${stockText}</div>
        `;

        card.addEventListener('click', () => {
            if (p.stock < 1) return;
            cart.addItem(p);
        });

        grid.appendChild(card);
    });
}

// ===== Filtering / sorting =====
function applyFilters() {
    const search = document.getElementById('searchInput').value.toLowerCase().trim();
    const category = document.getElementById('categoryFilter').value;
    const sort = document.getElementById('sortBy').value;

    let filtered = allProducts.filter(p => {
        const matchName = p.name.toLowerCase().includes(search);
        const matchCat = !category || p.category === category;
        return matchName && matchCat;
    });

    if (sort === 'price_asc') {
        filtered.sort((a, b) => a.price - b.price);
    } else if (sort === 'price_desc') {
        filtered.sort((a, b) => b.price - a.price);
    } else if (sort === 'name_asc') {
        filtered.sort((a, b) => a.name.localeCompare(b.name));
    }

    renderProducts(filtered);
}

// Barcode quick-add: if exact match, add it to cart
function handleBarcode(e) {
    if (e.key !== 'Enter') return;
    const code = e.target.value.trim();
    if (!code) return;

    const product = allProducts.find(p => p.barcode === code);
    if (product) {
        cart.addItem(product);
        e.target.value = '';
    } else {
        alert('No product found for barcode: ' + code);
    }
}

// ===== Checkout =====
function checkout() {
    if (cart.isEmpty()) {
        alert("Cart is empty!");
        return;
    }

    const payload = {
        items: cart.items.map(i => ({
            id: i.id,
            quantity: i.quantity,
            price: i.price
        })),
        total: cart.calculateTotal()
    };

    fetch('api/checkout.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert("Sale completed! Invoice #" + data.sale_id);
            cart.clear();
            loadProducts(); // refresh stock
        } else {
            alert("Checkout failed: " + (data.message || "Unknown error"));
        }
    })
    .catch(err => {
        console.error(err);
        alert("Error processing checkout");
    });
}

// ===== Event handlers =====
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();

    document.getElementById('searchInput').addEventListener('input', applyFilters);
    document.getElementById('categoryFilter').addEventListener('change', applyFilters);
    document.getElementById('sortBy').addEventListener('change', applyFilters);
    document.getElementById('barcodeInput').addEventListener('keydown', handleBarcode);

    document.getElementById('checkoutBtn').addEventListener('click', checkout);
    document.getElementById('clearCartBtn').addEventListener('click', () => {
        if (!cart.isEmpty() && confirm("Clear all items from cart?")) {
            cart.clear();
        }
    });
});
