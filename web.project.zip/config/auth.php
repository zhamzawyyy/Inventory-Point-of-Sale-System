<?php
// Simple session-based authentication helper
// Call require_login() at the top of any protected page

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function require_login() {
    if (!is_logged_in()) {
        // Figure out path back to root depending on where we are
        $root = '';
        if (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) {
            $root = '../';
        }
        header("Location: " . $root . "login.php");
        exit;
    }
}

function current_user() {
    return $_SESSION['username'] ?? 'Guest';
}
?>
