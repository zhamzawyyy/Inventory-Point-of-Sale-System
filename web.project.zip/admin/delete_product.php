<?php
require_once '../config/auth.php';
require_login();
require_once '../config/db.php';

$id = intval($_GET['id'] ?? 0);

if ($id < 1) {
    header("Location: products.php");
    exit;
}

try {
    // Check if product is referenced in past sales
    $check = $pdo->prepare("SELECT COUNT(*) FROM sale_items WHERE product_id = ?");
    $check->execute([$id]);
    $usedInSales = $check->fetchColumn();

    if ($usedInSales > 0) {
        // Product was sold before — can't delete (would break invoice history)
        header("Location: products.php?msg=delete_blocked");
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);

    header("Location: products.php?msg=deleted");
    exit;

} catch (PDOException $e) {
    header("Location: products.php?msg=delete_error");
    exit;
}
?>
