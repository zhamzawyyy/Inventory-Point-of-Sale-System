<?php
require_once '../config/auth.php';
require_login();
require_once '../config/db.php';

$id = intval($_GET['id'] ?? 0);
if ($id < 1) {
    header("Location: products.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $barcode = trim($_POST['barcode'] ?? '');
    $price = $_POST['price'] ?? 0;
    $stock = $_POST['stock'] ?? 0;

    if ($name === '' || $category === '') {
        $error = "Name and category are required.";
    } elseif (!is_numeric($price) || $price < 0) {
        $error = "Invalid price.";
    } elseif (!is_numeric($stock) || $stock < 0) {
        $error = "Invalid stock.";
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE products SET name=?, category=?, barcode=?, price=?, stock=? WHERE id=?");
            $stmt->execute([$name, $category, $barcode ?: null, $price, $stock, $id]);
            header("Location: products.php?msg=updated");
            exit;
        } catch (PDOException $e) {
            $error = "Update failed: " . $e->getMessage();
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    header("Location: products.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="topbar">
    <h1>QuickShop POS</h1>
    <nav>
        <a href="../index.php">POS</a>
        <a href="products.php" class="active">Inventory</a>
        <a href="../history.php">History</a>
        <a href="../logout.php">Logout</a>
    </nav>
</header>

<div class="container">
    <div class="page-header">
        <h2>Edit Product</h2>
        <a href="products.php" class="btn btn-secondary">← Back</a>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" class="form-card">
        <div class="form-group">
            <label>Product Name *</label>
            <input type="text" name="name" required value="<?= htmlspecialchars($product['name']) ?>">
        </div>

        <div class="form-group">
            <label>Category *</label>
            <input type="text" name="category" required value="<?= htmlspecialchars($product['category']) ?>">
        </div>

        <div class="form-group">
            <label>Barcode</label>
            <input type="text" name="barcode" value="<?= htmlspecialchars($product['barcode']) ?>">
        </div>

        <div class="form-group">
            <label>Price ($) *</label>
            <input type="number" name="price" step="0.01" min="0" required value="<?= $product['price'] ?>">
        </div>

        <div class="form-group">
            <label>Stock Quantity *</label>
            <input type="number" name="stock" min="0" required value="<?= $product['stock'] ?>">
        </div>

        <button type="submit" class="btn">Update Product</button>
    </form>
</div>

<footer class="footer">
    <p>&copy; <?= date('Y') ?> QuickShop POS</p>
</footer>

</body>
</html>
