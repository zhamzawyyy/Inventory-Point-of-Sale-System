<?php
require_once '../config/auth.php';
require_login();
require_once '../config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $barcode = trim($_POST['barcode'] ?? '');
    $price = $_POST['price'] ?? 0;
    $stock = $_POST['stock'] ?? 0;

    if ($name === '' || $category === '' || $price === '' || $stock === '') {
        $error = "All fields except barcode are required.";
    } elseif (!is_numeric($price) || $price < 0) {
        $error = "Price must be a positive number.";
    } elseif (!is_numeric($stock) || $stock < 0) {
        $error = "Stock must be 0 or higher.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO products (name, category, barcode, price, stock) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $category, $barcode ?: null, $price, $stock]);
            header("Location: products.php?msg=added");
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "Barcode already exists.";
            } else {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="topbar">
    <h1>QuickShop POS</h1>
    <nav>
        <a href="../index.php">POS</a>
        <a href="products.php" class="active">Inventory</a>
        <a href="../history.php">History</a>
        <a href="../logout.php">Logout</a>
    </nav>
</header>

<div class="container">
    <div class="page-header">
        <h2>Add New Product</h2>
        <a href="products.php" class="btn btn-secondary">← Back</a>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" class="form-card">
        <div class="form-group">
            <label>Product Name *</label>
            <input type="text" name="name" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label>Category *</label>
            <input type="text" name="category" required value="<?= htmlspecialchars($_POST['category'] ?? '') ?>" placeholder="e.g. Dairy, Snacks, Beverages">
        </div>

        <div class="form-group">
            <label>Barcode</label>
            <input type="text" name="barcode" value="<?= htmlspecialchars($_POST['barcode'] ?? '') ?>" placeholder="Optional">
        </div>

        <div class="form-group">
            <label>Price ($) *</label>
            <input type="number" name="price" step="0.01" min="0" required value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label>Stock Quantity *</label>
            <input type="number" name="stock" min="0" required value="<?= htmlspecialchars($_POST['stock'] ?? '') ?>">
        </div>

        <button type="submit" class="btn">Save Product</button>
    </form>
</div>

<footer class="footer">
    <p>&copy; <?= date('Y') ?> QuickShop POS</p>
</footer>

</body>
</html>
