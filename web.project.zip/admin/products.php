<?php
require_once '../config/auth.php';
require_login();
require_once '../config/db.php';

$stmt = $pdo->query("SELECT * FROM products ORDER BY name ASC");
$products = $stmt->fetchAll();

// Count low stock items
$lowStockCount = 0;
foreach ($products as $p) {
    if ($p['stock'] <= 5) $lowStockCount++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory - Manage Products</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="topbar">
    <h1>QuickShop POS</h1>
    <nav>
        <a href="../index.php">POS</a>
        <a href="products.php" class="active">Inventory</a>
        <a href="../history.php">History</a>
        <a href="../logout.php">Logout</a>
    </nav>
</header>

<div class="container">
    <div class="page-header">
        <h2>
            Products
            <?php if ($lowStockCount > 0): ?>
                <span class="badge"><?= $lowStockCount ?> low stock</span>
            <?php endif; ?>
        </h2>
        <a href="add_product.php" class="btn">+ Add Product</a>
    </div>

    <?php if (isset($_GET['msg'])): ?>
        <?php
        $msg = $_GET['msg'];
        $successMessages = [
            'added' => 'Product added successfully.',
            'updated' => 'Product updated successfully.',
            'deleted' => 'Product deleted successfully.'
        ];
        $errorMessages = [
            'delete_blocked' => 'Cannot delete: this product appears in past invoices. Set stock to 0 instead.',
            'delete_error' => 'Could not delete the product. Please try again.'
        ];
        if (isset($successMessages[$msg])): ?>
            <div class="alert alert-success"><?= $successMessages[$msg] ?></div>
        <?php elseif (isset($errorMessages[$msg])): ?>
            <div class="alert alert-error"><?= $errorMessages[$msg] ?></div>
        <?php endif; ?>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Barcode</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($products) === 0): ?>
                <tr><td colspan="7" style="text-align:center;">No products yet.</td></tr>
            <?php endif; ?>
            <?php foreach ($products as $p): ?>
                <tr>
                    <td><?= $p['id'] ?></td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= htmlspecialchars($p['category']) ?></td>
                    <td><?= htmlspecialchars($p['barcode']) ?></td>
                    <td>$<?= number_format($p['price'], 2) ?></td>
                    <td class="<?= $p['stock'] <= 5 ? 'low-stock' : '' ?>">
                        <?= $p['stock'] ?>
                        <?= $p['stock'] <= 5 ? '⚠️' : '' ?>
                    </td>
                    <td class="action-cell">
                        <a href="edit_product.php?id=<?= $p['id'] ?>" class="btn btn-secondary">Edit</a>
                        <a href="delete_product.php?id=<?= $p['id'] ?>"
                           class="btn btn-danger"
                           onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<footer class="footer">
    <p>&copy; <?= date('Y') ?> QuickShop POS</p>
</footer>

</body>
</html>
